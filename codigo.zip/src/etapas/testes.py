import boto3
from botocore.exceptions import NoCredentialsError
from dotenv import load_dotenv
import os
import pandas as pd
from io import BytesIO

def ler_arquivo_para_dataframe(bucket_name, s3_key, file_type='csv'):
    """
    Lê um arquivo do S3 e carrega em um DataFrame do Pandas.
    
    :param bucket_name: Nome do bucket.
    :param s3_key: Caminho do arquivo no S3.
    :param file_type: Tipo do arquivo ('csv' ou 'xlsx').
    :return: DataFrame do Pandas.
    """
    try:
        response = s3.get_object(Bucket=bucket_name, Key=s3_key)
        if file_type == 'csv':
            df = pd.read_csv(BytesIO(response['Body'].read()))
        elif file_type == 'xlsx':
            df = pd.read_excel(BytesIO(response['Body'].read()))
        else:
            raise ValueError("Tipo de arquivo não suportado. Use 'csv' ou 'xlsx'.")
        print(f"Arquivo '{s3_key}' lido com sucesso!")
        return df
    except Exception as e:
        print(f"Erro ao ler arquivo do S3: {e}")
        return None
    

# Carregando variáveis de ambiente
dotenv_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '.env'))
print(f"Carregando .env de: {dotenv_path}")
load_dotenv(dotenv_path, override=True)

# Configurar o cliente S3
s3 = boto3.client('s3', 
                  aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'), 
                  aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
                  region_name=os.getenv('AWS_DEFAULT_REGION')
                  )

# Nome do bucket
bucket_name = '4btaxtech'

def listar_estrutura(bucket_name, prefixo="Cat42/tateti/"):
    """
    Lista a estrutura de arquivos e "pastas" dentro do bucket S3.
    :param bucket_name: Nome do bucket S3.
    :param prefixo: Caminho inicial para listar (opcional).
    """
    try:
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefixo, Delimiter='/')
        
        # Listar "pastas" (prefixos comuns)
        if 'CommonPrefixes' in response:
            print("Pastas:")
            for folder in response['CommonPrefixes']:
                print(f"- {folder['Prefix']}")
        
        # Listar arquivos
        if 'Contents' in response:
            print("\nArquivos:")
            for obj in response['Contents']:
                print(f"- {obj['Key']}")
        else:
            print("Nenhum arquivo encontrado.")

    except NoCredentialsError:
        print("Credenciais não encontradas.")
    except Exception as e:
        print(f"Erro ao listar estrutura: {e}")

# Exemplo de uso
if __name__ == "__main__":
    print(f"Estrutura do bucket '{bucket_name}':")
    listar_estrutura(bucket_name)

# def criar_pasta(bucket_name, caminho_pasta):
#     """
#     Cria uma "pasta" no bucket S3.
    
#     :param bucket_name: Nome do bucket.
#     :param caminho_pasta: Caminho da "pasta" (deve terminar com /).
#     """
#     if not caminho_pasta.endswith('/'):
#         caminho_pasta += '/'
    
#     try:
#         s3.put_object(Bucket=bucket_name, Key=caminho_pasta)
#         print(f"Pasta '{caminho_pasta}' criada com sucesso no bucket '{bucket_name}'.")
#     except NoCredentialsError:
#         print("Credenciais não encontradas.")
#     except Exception as e:
#         print(f"Erro ao criar pasta: {e}")

# # Exemplo de uso
# if __name__ == "__main__":
#     bucket_name = "4btaxtech"
#     caminho_pasta = "Cat42/Tateti/Txts/Teste_CNPJ_65369985000504"
#     criar_pasta(bucket_name, caminho_pasta)


# def listar_arquivos_s3(bucket, prefix):
#     response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
#     return [obj['Key'] for obj in response.get('Contents', []) if obj['Key'].endswith('.xlsx')]

# # Verificar arquivos XML na pasta
# def verificar_arquivos(bucket, pasta_origem):
#     arquivos = listar_arquivos_s3(bucket, pasta_origem)
#     if arquivos:
#         print(f"Foram encontrados {len(arquivos)} arquivos XML na pasta '{pasta_origem}':")
#         for arquivo in arquivos:
#             print(f"- {arquivo}")
#     else:
#         print(f"Nenhum arquivo XML foi encontrado na pasta '{pasta_origem}'.")

# # Configurações do S3
# pasta_origem = 'Cat42/Tateti/Tabela 1'

# verificar_arquivos(bucket_name, pasta_origem)

# # Verificar arquivos XML
# df = ler_arquivo_para_dataframe(bucket_name, 'Cat42/Tateti/Tabela 1/tabela_1.xlsx', file_type='xlsx')
# print(df.head())