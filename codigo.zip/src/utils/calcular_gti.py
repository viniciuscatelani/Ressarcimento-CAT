import pandas as pd
import numpy as np

from src.utils.calcular_ressarcimento import calcular_ressarcimento

def gti_pra_cima(tabela_2, meta):
    
    '''
    Função para aplicação de GTI para lojas
    com ressarcimento abaixo da porcentagem estabelecida
    como meta
    
    '''

    valor = tabela_2[tabela_2['CFOP'] == 5405]['VALOR'].sum()
    ressarc = tabela_2['VLR_RESSARCIMENTO'].sum()
    fator = 0.1
    
    # 1ª Iteração
    
    tabela_2['COD_ITEM'] = tabela_2['COD_ITEM'].astype(str)
    pivot_ressarc = tabela_2[tabela_2['tipo'] == 'grupo'].pivot_table(index='COD_ITEM', values='VLR_RESSARCIMENTO', aggfunc='sum')
    pivot_ressarc = pivot_ressarc[pivot_ressarc['VLR_RESSARCIMENTO'] > 0]
    pivot_ressarc = pivot_ressarc.sort_values(by='VLR_RESSARCIMENTO', ascending=False)  
    
    incr_max_ref = pivot_ressarc.iloc[54].values[0]
    incr_max = pivot_ressarc.iloc[55:]
    incr_max['Diferenças'] = incr_max_ref - incr_max['VLR_RESSARCIMENTO']
    incr_max = incr_max.sort_values(by='COD_ITEM')
    
    qtd_saida = tabela_2[tabela_2['CFOP'] == 5405].pivot_table(index='COD_ITEM', values='QTD_CAT', aggfunc='sum')
    incr_max_unit = incr_max.merge(qtd_saida, on='COD_ITEM', how='left')
    incr_max_unit['Incremento maximo unitario'] = incr_max_unit['Diferenças'] / incr_max_unit['QTD_CAT']
    incr_max_unit = incr_max_unit.reset_index()
    
    tabela_2_nova = tabela_2.merge(incr_max_unit[['COD_ITEM', 'Incremento maximo unitario']], on='COD_ITEM', how='left')
    tabela_2_nova['Incremento maximo unitario'] = np.where(tabela_2_nova['ICMS_TOT'].fillna(0) == 0,
                                                 0,
                                                 tabela_2_nova['Incremento maximo unitario'])
    
    tabela_2_nova['Incremento maximo unitario'] = tabela_2_nova['Incremento maximo unitario'].fillna(0)
    
    tabela_2_nova['ICMS_TOT_FINAL'] = np.where(tabela_2_nova['ICMS_TOT'].fillna(0) != 0,
                                     tabela_2_nova['ICMS_TOT'] + (tabela_2_nova['Incremento maximo unitario']*fator)*tabela_2_nova['QTD_CAT'],
                                     0)
    
    tabela_2_nova['bc ST op ant'] = np.where(tabela_2_nova['ALIQUOTA'] != 0,
                                   tabela_2_nova['ICMS_TOT_FINAL'] / (tabela_2_nova['ALIQUOTA']/100),
                                   tabela_2_nova['Valor Base Cálculo ICMS ST Retido Operação Anterior'])
    
    tabela_2_nova['bc ST op ant comple'] = tabela_2_nova['bc ST op ant'] - tabela_2_nova['Valor Base Cálculo ICMS ST Retido Operação Anterior']
    
    df_final = tabela_2.copy()
    df_final = df_final.sort_values(by=['COD_ITEM', 'DATA', 'IND_OPER', 'SUB_TIPO'], 
                                   ascending=[True, True, True, True]).reset_index().drop(['index'], axis=1)
    
    df_final['bc ST op ant comple'] = tabela_2_nova['bc ST op ant comple'],
                                               
    
    df_final.rename(columns={'ICMS_TOT': 'ICMS_TOT_ORIG',
                            'Valor Complementar': 'Complementar Original',
                            'bc ST op ant comple': 'Valor Complementar'}, inplace=True)
    
    df_final['ICMS_TOT'] = np.where(df_final['Valor Base Cálculo ICMS ST Retido Operação Anterior'] <= df_final['vBCST'],
             np.maximum(df_final['Valor ICMS Operação'].fillna(0) + df_final['Valor ICMS Substituição Tributária'].fillna(0), (df_final['Valor Base Cálculo ICMS ST Retido Operação Anterior'] + df_final['Valor Complementar'].fillna(0)) * df_final['ALIQUOTA'].fillna(0).astype(float)/100),
             np.maximum(df_final['Valor ICMS Operação'].fillna(0) + df_final['Valor ICMS Substituição Tributária'].fillna(0), (df_final['vBCST'] + df_final['Valor Complementar'].fillna(0)) * df_final['ALIQUOTA'].fillna(0).astype(float)/100))

    
    tabela_2_final = calcular_ressarcimento(df_final)
    
    # 2ª Iteração
    ressarc_tot_0_1 = tabela_2_final['VLR_RESSARCIMENTO'].sum()
    delta_fator_0_1 = ressarc_tot_0_1 - ressarc
    meta = meta
    meta_ressarc = valor * meta
    meta_delta = meta_ressarc - ressarc
    meta_fator_0_1 = meta_delta/delta_fator_0_1
    meta_fator = meta_fator_0_1*0.1*0.95
    
    tabela_2_final['COD_ITEM'] = tabela_2_final['COD_ITEM'].astype(str)
    pivot_ressarc_final = tabela_2_final[tabela_2_final['tipo'] == 'grupo'].pivot_table(index='COD_ITEM', values='VLR_RESSARCIMENTO', aggfunc='sum')
    pivot_ressarc_final = pivot_ressarc_final[pivot_ressarc_final['VLR_RESSARCIMENTO'] > 0]
    pivot_ressarc_final = pivot_ressarc_final.sort_values(by='VLR_RESSARCIMENTO', ascending=False)
    
    
    incr_max_ref_final = pivot_ressarc_final.iloc[54].values[0]
    incr_max_final = pivot_ressarc_final.iloc[55:]
    incr_max_final['Diferenças'] = incr_max_ref_final - incr_max_final['VLR_RESSARCIMENTO']
    incr_max_final = incr_max_final.sort_values(by='COD_ITEM')
    
    qtd_saida_final = tabela_2_final[tabela_2_final['CFOP'] == 5405].pivot_table(index='COD_ITEM', values='QTD_CAT', aggfunc='sum')
    incr_max_unit_final = incr_max_final.merge(qtd_saida_final, on='COD_ITEM', how='left')
    incr_max_unit_final['Incremento maximo unitario'] = incr_max_unit_final['Diferenças'] / incr_max_unit_final['QTD_CAT']
    
    incr_max_unit_final = incr_max_unit_final.reset_index()
    
    tabela_2_final['ICMS_TOT_ORIG'] = df_final['ICMS_TOT_ORIG']
    tabela_2_final = tabela_2_final.merge(incr_max_unit_final[['COD_ITEM', 'Incremento maximo unitario']], on='COD_ITEM', how='left')
    tabela_2_final['Incremento maximo unitario'] = np.where(tabela_2_final['ICMS_TOT_ORIG'].fillna(0) == 0,
                                                 0,
                                                 tabela_2_final['Incremento maximo unitario'])
    tabela_2_final['Incremento maximo unitario'] = tabela_2_final['Incremento maximo unitario'].fillna(0)
    
    tabela_2_final['ICMS_TOT_FINAL'] = np.where(tabela_2_final['ICMS_TOT_ORIG'].fillna(0) != 0,
                                     tabela_2_final['ICMS_TOT_ORIG'] + (tabela_2_final['Incremento maximo unitario']*meta_fator)*tabela_2_final['QTD_CAT'],
                                     0)
    
    tabela_2_final['bc ST op ant'] = np.where(tabela_2_final['ALIQUOTA'] != 0,
                                   tabela_2_final['ICMS_TOT_FINAL'] / (tabela_2_final['ALIQUOTA']/100),
                                   tabela_2_final['Valor Base Cálculo ICMS ST Retido Operação Anterior'])
    
    tabela_2_final['bc ST op ant comple'] = tabela_2_final['bc ST op ant'] - tabela_2_final['Valor Base Cálculo ICMS ST Retido Operação Anterior']
    
    
    df_fim = tabela_2.copy()
    df_fim = df_fim.sort_values(by=['COD_ITEM', 'DATA', 'IND_OPER', 'SUB_TIPO'], 
                                   ascending=[True, True, True, True]).reset_index().drop(['index'], axis=1)
    
    df_fim['bc ST op ant comple'] = tabela_2_final['Valor Complementar']
    
    df_fim.rename(columns={'ICMS_TOT': 'ICMS_TOT_ORIG',
                            'Valor Complementar': 'Complementar Original',
                            'bc ST op ant comple': 'Valor Complementar'}, inplace=True)
    
    df_fim['ICMS_TOT'] = np.where(df_fim['Valor Base Cálculo ICMS ST Retido Operação Anterior'] <= df_fim['vBCST'],
             np.maximum(df_fim['Valor ICMS Operação'].fillna(0) + df_fim['Valor ICMS Substituição Tributária'].fillna(0), (df_fim['Valor Base Cálculo ICMS ST Retido Operação Anterior'] + df_fim['Valor Complementar'].fillna(0)) * df_fim['ALIQUOTA'].fillna(0).astype(float)/100),
             np.maximum(df_fim['Valor ICMS Operação'].fillna(0) + df_fim['Valor ICMS Substituição Tributária'].fillna(0), (df_fim['vBCST'] + df_fim['Valor Complementar'].fillna(0)) * df_fim['ALIQUOTA'].fillna(0).astype(float)/100))
    
    tabela_2_fim = calcular_ressarcimento(df_fim)
    
    return tabela_2_fim

def gti_pra_baixo(tabela_2, ficha_3, meta):
    '''
    Função para aplicação de GTI para lojas
    com ressarcimento acima da porcentagem estabelecida
    como meta
    
    '''

    # Cálculo de ressarcimento por produto
    ressarc = ficha_3['VLR_RESSARCIMENTO'].sum()
    meta_ressarc = ficha_3[ficha_3['CFOP'] == 5405]['VALOR'].sum() * meta
    diferenca = ressarc-meta_ressarc
    pivot_ressarc = ficha_3.pivot_table(index='COD_ITEM', values='VLR_RESSARCIMENTO', aggfunc='sum')
    pivot_ressarc = pivot_ressarc[pivot_ressarc['VLR_RESSARCIMENTO'] > 0].sort_values(by='VLR_RESSARCIMENTO',
                                                                                     ascending=True)

    # Definição dos produtos a terem código legal mudado de 1 para 0 e valor de confronto para nulo
    soma = 0
    i = 0
    cods = []
    while i < len(pivot_ressarc) and (soma + pivot_ressarc['VLR_RESSARCIMENTO'].iloc[i]) <= diferenca:
        soma += pivot_ressarc['VLR_RESSARCIMENTO'].iloc[i]
        cods.append(pivot_ressarc.index[i])
        i += 1
    
    tabela_2['COD_LEGAL'] = np.where(tabela_2['COD_ITEM'].isin(cods),
                              np.where(tabela_2['COD_LEGAL'].isnull(), tabela_2['COD_LEGAL'], 0),
                              tabela_2['COD_LEGAL'])
    
    tabela_2['VL_CONFR_0'] = np.where(tabela_2['COD_ITEM'].isin(cods),
                               np.nan,
                               tabela_2['VL_CONFR_0'])
    
    tabela_2_final = calcular_ressarcimento(tabela_2)
    
    return tabela_2_final